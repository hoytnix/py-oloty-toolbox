def determine_timezone(coords=[27.994195699999999, -82.569434900000005]):
	'''
	timezones = {
		'p1'   :  (49.189787, -67.444574),
		'p2'   :  (24.660845, -67.444574),
		'p3'   :  (49.189787, -87.518395),
		'p4'   :  (24.660845, -87.518395),
		'p5'   :  (49.189787, -101.998892),
		'p6'   :  (24.660845, -101.998892),
		'p7'   :  (49.189787, -115.236428),
		'p8'   :  (24.660845, -115.236428),
		'p9'   :  (49.189787, -125.242264),
		'p10'  :  (24.660845, -125.242264)
	}
	''' # Latitude doesn't matter.

	eastern  = -87.518395  # < central
	central  = -101.998892 # > eastern && < cent
	mountain = -115.236428 # > cent && < pac
	pacific  = -125.242264 # > mount

	long = coords[1]

	# Eastern Timezone
	if long > eastern:
		return 'Eastern'
	if long < eastern and long > central:
		return 'Central'
	if long < central and long > pacific:
		return 'Mountain'
	if long < mountain:
		return 'Pacific'
	return False

class Ass:
	def __init__(self):
		# Data structures.
		self.tweets = []
		self.keywords = []
		self.timezones = {
			'Eastern': [],
			'Central': [],
			'Mountain': [],
			'Pacific': []
		}

		# File inputs.
		r = '{file} does not exist. Please try again.'
		while True:
			self.tweets_file = input('Tweets file: ')
			if not self.parse_tweets_file():
				print(r.format(file=self.tweets_file))
			else:
				break
		while True:
			self.keywords_file = input('Keywords file: ')
			if not self.parse_keywords_file():
				print(r.format(file=self.keywords_file))
			else:
				break

		# Populate data structures.
		for tweet in self.tweets:
			score = self.happiness_score(tweet=tweet)
			timezone = determine_timezone(coords=tweet['coords'])
			self.timezones[timezone].append(score)

		# Timezone average.
		for timezone_key in self.timezones:
			statement_r = '{timezone}: Happiness of {happiness:.3f} over {tweets} tweets.'
			timezone = self.timezones[timezone_key]
			if timezone.__len__() > 0: #please dont divide by 0
				average = (sum(timezone) / timezone.__len__())
				statement = statement_r.format(timezone=timezone_key, happiness=average, tweets=timezone.__len__())
				print(statement)
			else:
				print(timezone_key, 0)

	def happiness_score(self, tweet):
		text = tweet['text']
		score = 0
		for keyword in self.keywords:
			if keyword['word'] in text.lower():
				score += keyword['value']
		return score

	def parse_keywords_file(self):
		lines = []

		try:
			with open(self.keywords_file, 'r') as f:
				for line in f:
					lines.append(line.strip())
		except:
			return False

		for line in lines:
			line = line.split(',')
			self.keywords.append( {
				'word':  line[0],
				'value': int(line[1])
			} )

		return True

	def parse_tweets_file(self):
		lines = []

		try:
			with open(self.tweets_file, 'r', encoding='utf-8') as f: #YOLO DICK BAG WITH SPECIAL CHARACTERS
				for line in f:
					lines.append(line.strip())
		except:
			return False

		for line in lines:
			# Find the first [, data may be corrupt so don't rely on it always being at the 0 index.
			start = None
			end   = None
			index = 0
			while(True):
				c = line[index]
				if c is '[':
					start = index + 1
					break
				elif index == line.__len__():
					break
				index += 1

			# Find the ]
			while(True):
				c = line[index]
				if c is ']':
					end = index - 1
					break
				elif index == line.__len__():
					break
				index += 1

			if start and end:
				coords = [float(x) for x in line.replace(' ', '')[start:end].split(',')]
				text = ' '.join(line[end+2:].split(' ')[3:]) #hax

				self.tweets.append({'coords': coords, 'text': text})

		return True

def main():
	a = Ass()

# Only executes the program if run by itself (python ass.py); allows the class to be imported by a seperate file.
if __name__ == '__main__':
	main()