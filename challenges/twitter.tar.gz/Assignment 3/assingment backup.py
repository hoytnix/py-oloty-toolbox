def determine_timezone(coords=[27.994195699999999, -82.569434900000005]):
	timezones = {
		"""
		'p1'   :  (49.189787, -67.444574),
		'p2'   :  (24.660845, -67.444574),
		'p3'   :  (49.189787, -87.518395),
		'p4'   :  (24.660845, -87.518395),
		'p5'   :  (49.189787, -101.998892),
		'p6'   :  (24.660845, -101.998892),
		'p7'   :  (49.189787, -115.236428),
		'p8'   :  (24.660845, -115.236428),
		'p9'   :  (49.189787, -125.242264),
		'p10'  :  (24.660845, -125.242264)
		"""

	}

	eastern  = -87.518395  # < cent
	central  = -101.998892 # > east && < cent
	mountain = -115.236428 # > cent && < pac
	pacific  = -125.242264 # > mount

	long = coords[1]

	# Eastern Timezone
	if long > eastern:
		print('Eastern')
	if long < eastern and long > central:
		print('Central')
	if long < central and long > pacific:
		print('Mountain')
	if long < mountain:
		print('Pacific')

class Ass:
	def __init__(self):
		# Data structures.
		self.tweets = []
		self.keywords = []

		# File locations: Should request user input.
		self.tweets_file   = 'tweets.txt'
		self.keywords_file = 'keywords.txt'

		# Do the thing.
		self.parse_tweets_file()
		self.parse_keywords_file()

		# Test happiness score.
		'''
		for tweet in self.tweets:
			score = self.happiness_score(tweet=tweet)
			print(score, tweet)
		'''

		# Test timezones.
		for tweet in self.tweets:
			print(tweet)

	def happiness_score(self, tweet):
		text = tweet['text']
		score = 0
		for keyword in self.keywords:
			if keyword['word'] in text:
				score += keyword['value']
		return score

	def parse_keywords_file(self):
		lines = []
		with open(self.keywords_file, 'r') as f:
			for line in f:
				lines.append(line.strip())

		for line in lines:
			line = line.split(',')
			self.keywords.append( {
				'word':  line[0],
				'value': int(line[1])
			} )

	def parse_tweets_file(self):
		lines = []
		with open(self.tweets_file, 'r') as f:
			for line in f:
				lines.append(line.strip())

		for line in lines:
			# Find the first [, data may be corrupt so don't rely on it always being at the 0 index.
			start = None
			end   = None
			index = 0
			while(True):
				c = line[index]
				if c is '[':
					start = index + 1
					break
				elif index == line.__len__():
					break
				index += 1

			# Find the ]
			while(True):
				c = line[index]
				if c is ']':
					end = index - 1
					break
				elif index == line.__len__():
					break
				index += 1

			if start and end:
				coords = [float(x) for x in line.replace(' ', '')[start:end].split(',')]
				text = ' '.join(line[end+2:].split(' ')[3:]) #hax

				self.tweets.append({'coords': coords, 'text': text})

def main():
	a = Ass()

if __name__ == '__main__':
	main()